-- SteadyMaze Student Portal: additive Supabase setup
-- Run in Supabase SQL Editor after reviewing existing table names.
-- Uses auth.uid() for student ownership. Never expose service_role keys in browser.

create table if not exists public.sm_wallet_ledger (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references auth.users(id) on delete cascade,
  entry_type text not null check (entry_type in ('earning','commission','refund','payout','adjustment')),
  amount numeric(12,2) not null,
  currency text not null default 'USD',
  status text not null default 'pending' check (status in ('pending','confirmed','paid','reversed')),
  description text,
  source_type text,
  source_id uuid,
  created_at timestamptz not null default now()
);

create index if not exists sm_wallet_student_created_idx
  on public.sm_wallet_ledger(student_id, created_at desc);

create table if not exists public.sm_support_listings (
  id uuid primary key default gen_random_uuid(),
  creator_id uuid not null references auth.users(id) on delete cascade,
  title text not null,
  description text,
  skill_name text,
  price numeric(12,2),
  currency text not null default 'USD',
  status text not null default 'pending_review'
    check (status in ('pending_review','approved','rejected','paused','closed')),
  creator_consent boolean not null default false,
  license_terms text,
  approved_at timestamptz,
  created_at timestamptz not null default now(),
  constraint sm_support_consent_required check
    (status not in ('approved','paused') or (creator_consent = true and license_terms is not null))
);

create index if not exists sm_support_listing_status_idx
  on public.sm_support_listings(status, created_at desc);

create table if not exists public.sm_support_applications (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.sm_support_listings(id) on delete cascade,
  worker_id uuid not null references auth.users(id) on delete cascade,
  status text not null default 'pending'
    check (status in ('pending','approved','rejected','withdrawn')),
  commission_rate numeric(5,2) not null default 20
    check (commission_rate >= 0 and commission_rate <= 100),
  created_at timestamptz not null default now(),
  unique(listing_id, worker_id)
);

create table if not exists public.sm_support_sales (
  id uuid primary key default gen_random_uuid(),
  listing_id uuid not null references public.sm_support_listings(id),
  creator_id uuid not null references auth.users(id),
  worker_id uuid references auth.users(id),
  buyer_id uuid references auth.users(id),
  gross_amount numeric(12,2) not null check (gross_amount >= 0),
  creator_share numeric(12,2) not null default 0,
  worker_share numeric(12,2) not null default 0,
  platform_share numeric(12,2) not null default 0,
  currency text not null default 'USD',
  status text not null default 'pending'
    check (status in ('pending','confirmed','refunded','paid')),
  created_at timestamptz not null default now()
);

-- Student can read only their own ledger. Ledger writes are server/admin-only.
alter table public.sm_wallet_ledger enable row level security;
drop policy if exists "students_read_own_wallet" on public.sm_wallet_ledger;
create policy "students_read_own_wallet"
on public.sm_wallet_ledger for select
to authenticated using (student_id = (select auth.uid()));

-- Listing visibility: approved listings are public to signed-in students;
-- creators can also read their own submissions.
alter table public.sm_support_listings enable row level security;
drop policy if exists "read_approved_or_own_listings" on public.sm_support_listings;
create policy "read_approved_or_own_listings"
on public.sm_support_listings for select
to authenticated using (
  status = 'approved' or creator_id = (select auth.uid())
);
drop policy if exists "creator_submit_listing" on public.sm_support_listings;
create policy "creator_submit_listing"
on public.sm_support_listings for insert
to authenticated with check (
  creator_id = (select auth.uid()) and status = 'pending_review'
);
drop policy if exists "creator_update_own_pending_listing" on public.sm_support_listings;
create policy "creator_update_own_pending_listing"
on public.sm_support_listings for update
to authenticated using (
  creator_id = (select auth.uid()) and status in ('pending_review','rejected')
) with check (
  creator_id = (select auth.uid()) and status in ('pending_review','rejected')
);

-- Support worker sees own applications; creator sees applications for their listings.
alter table public.sm_support_applications enable row level security;
drop policy if exists "worker_or_creator_read_applications" on public.sm_support_applications;
create policy "worker_or_creator_read_applications"
on public.sm_support_applications for select
to authenticated using (
  worker_id = (select auth.uid()) or exists (
    select 1 from public.sm_support_listings l
    where l.id = listing_id and l.creator_id = (select auth.uid())
  )
);
drop policy if exists "worker_apply_to_listing" on public.sm_support_applications;
create policy "worker_apply_to_listing"
on public.sm_support_applications for insert
to authenticated with check (
  worker_id = (select auth.uid()) and exists (
    select 1 from public.sm_support_listings l
    where l.id = listing_id and l.status = 'approved'
  )
);

-- Sales are visible only to parties involved. Inserts/settlement must be done
-- by a trusted backend (Edge Function / server with service role).
alter table public.sm_support_sales enable row level security;
drop policy if exists "parties_read_own_sales" on public.sm_support_sales;
create policy "parties_read_own_sales"
on public.sm_support_sales for select
to authenticated using (
  creator_id = (select auth.uid())
  or worker_id = (select auth.uid())
  or buyer_id = (select auth.uid())
);

-- IMPORTANT:
-- Do not add client INSERT/UPDATE policies for wallet ledger or sales.
-- Payment verification, commission calculations, refunds and payouts must be
-- performed by trusted server-side code after validating the payment provider.
