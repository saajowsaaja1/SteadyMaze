# SteadyMaze Student Portal update

## What changed
- Replaced `student.html` with a responsive luxury dark-purple student workspace.
- Added 13 working navigation destinations (pages/sections).
- Added Supabase Auth session detection and sign-out.
- Reads the signed-in student's `profiles` record and their own `transactions` rows.
- Earnings are calculated from returned transaction records; no demo balances are inserted.
- Added Support Market consent and commission workflow guidance.

## Supabase
The frontend uses the project's existing Supabase URL and publishable key. Publishable keys are intended for browser use only when Row Level Security is enabled. Never put a service-role/secret key in HTML or JavaScript.

Review and run `supabase_student_portal_setup.sql` in Supabase SQL Editor. It creates additive `sm_*` tables and RLS policies for wallet ledger and support marketing. It does not overwrite your existing tables.

## Important integration notes
- Existing project tables are not assumed to have identical columns. The current earnings page reads the existing `transactions` table by `student_id` and shows an error if the schema/policy does not match.
- Wallet ledger and support sales are read-only from the browser by design. Payment verification, commissions, payouts and refunds must be handled server-side (e.g. Supabase Edge Functions).
- Competition capacity (900,000), atomic entry registration, cycle scheduling and 8-video reservation entitlement still need server-side database functions and integration with your existing competition schema before enabling registration.
- Deploy the updated `student.html` alongside the existing HTML files in the repository. Keep `login.html` in the same folder.
